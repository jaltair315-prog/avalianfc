# Direção visual — Avalia NFC

## Exploração inicial

### 1. Sinal de confiança
Painel editorial-operacional com azul petróleo, ciano e âmbar; transmite clareza, leitura rápida e confiança para uma ferramenta de placas físicas. Probabilidade: 0,08.

### 2. Oficina gráfica local
Visual mais tátil e caloroso, com papel cru, verde escuro e laranja de gráfica; aproxima o produto de pequenos negócios e materiais impressos. Probabilidade: 0,07.

### 3. Rede silenciosa
Interface quase monocromática, escura e técnica, com acentos elétricos; transmite infraestrutura, mas pode ficar fria para uma operação comercial. Probabilidade: 0,06.

## Direção escolhida: Sinal de confiança

### Movimento de design
Dashboard operacional com traços de editorial de serviço: blocos sólidos, linhas de leitura e marcadores de sinal. O produto deve parecer um centro de controle confiável, não um painel SaaS genérico.

### Princípios
- Um olhar deve revelar quantas placas estão prontas.
- A ação importante fica perto do contexto da placa.
- Virgem é um estado compreensível e acionável, não um erro.
- O contraste serve à leitura em desktop e celular.
- Cor de marca aparece em pontos de decisão, sem cobrir a tela inteira.

### Filosofia de cor
- Fundo: marfim frio `#F5F7F6`, com superfícies brancas para o conteúdo.
- Marca: azul petróleo `#102A33`.
- Sinal positivo: ciano `#18B6A4`.
- Atenção: âmbar `#E4A83A`.
- Texto: azul quase preto `#102A33` e cinza azul `#64747B`.
- Bordas: `#DCE6E4`.

### Paradigma de layout
Cabeçalho compacto com marca e perfil; faixa de resumo com números grandes; toolbar de busca e criação; tabela em cartões no celular. Painel de configurações como seção expansível para manter a operação principal sempre visível.

### Elementos assinatura
- Ícone de marca formado por uma etiqueta NFC abstrata atravessada por duas ondas de sinal.
- Pequeno fio ciano vertical antes de títulos de seção.
- Pílulas de status com ponto sólido.
- Bloco de taxa de ativação com barra de sinal segmentada.

### Filosofia de interação
Salvar é explícito e confirma a placa no lugar. A edição não abre uma tela separada: o operador permanece na lista. Erros aparecem junto ao campo com uma frase prática. Downloads usam nomes previsíveis e o link público tem ação de copiar próxima ao slug.

### Animação
Transições curtas (160–220ms) em hover, foco e expansão. Nada de animação decorativa contínua; o máximo é uma barra de progresso breve para downloads.

### Tipografia
- Display: `Space Grotesk`, com peso 600/700 para números e títulos.
- Corpo: `DM Sans`, peso 400/500 para leitura e controles.
- Mono: `IBM Plex Mono` em URLs e slugs.

### Essência da marca
“Transformar um toque em uma avaliação certa.”

### Voz
Clara, próxima e operacional. Frases curtas: “Ative a placa”, “Link salvo”, “Copie o endereço público”. Evitar jargão de infraestrutura na interface.

### Wordmark/logo
Wordmark “Avalia NFC” em texto, acompanhado do símbolo de etiqueta com ondas NFC. O símbolo funciona sozinho em 24–48px e em favicon.

### Cor assinatura
Ciano de sinal `#18B6A4`, usado em botões primários, estados ativos e o detalhe do símbolo.
