import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  AlertCircle, ArrowUpRight, Check, ChevronDown, CircleHelp, Copy, Download,
  FileText, Link2, Loader2, LogOut, MoreHorizontal, Plus, QrCode, Radio,
  Search, Settings2, ShieldCheck, Sparkles,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

type Board = {
  id: number;
  sequence: number;
  slug: string;
  name: string;
  googleReviewUrl: string | null;
  status: "virgin" | "active";
  redirectCode: "301" | "302";
};

type Settings = {
  virginMode: "whatsapp" | "message";
  salesWhatsapp: string | null;
  virginMessage: string;
  defaultRedirectCode: "301" | "302";
};

function BrandMark({ className = "" }: { className?: string }) {
  return <span className={`block h-10 w-10 overflow-hidden rounded-xl bg-[#102A33] shadow-sm ${className}`}><img src="/logo.png" alt="Avalia NFC" className="h-full w-full object-cover" /></span>;
}

function StatusPill({ status }: { status: Board["status"] }) {
  const active = status === "active";
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold ${active ? "bg-[#E4F8F4] text-[#087C70]" : "bg-[#FFF5DF] text-[#A56505]"}`}><i className={`h-1.5 w-1.5 rounded-full ${active ? "bg-[#18B6A4]" : "bg-[#E4A83A]"}`} />{active ? "Ativa" : "Virgem"}</span>;
}

function copyText(value: string, label: string) {
  navigator.clipboard.writeText(value).then(() => toast.success(`${label} copiado`)).catch(() => toast.error("Não foi possível copiar agora."));
}

async function downloadProtected(url: string, fallbackName: string) {
  try {
    const separator = url.includes("?") ? "&" : "?";
    const response = await fetch(`${url}${separator}baseUrl=${encodeURIComponent(window.location.origin)}`, { credentials: "include" });
    if (!response.ok) {
      const body = await response.json().catch(() => null) as { error?: string } | null;
      throw new Error(body?.error || "Não foi possível preparar o download.");
    }
    const disposition = response.headers.get("content-disposition") ?? "";
    const filename = disposition.match(/filename=\"?([^\";]+)\"?/i)?.[1] ?? fallbackName;
    const blobUrl = URL.createObjectURL(await response.blob());
    const anchor = document.createElement("a");
    anchor.href = blobUrl;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(blobUrl);
    toast.success("Download iniciado");
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Não foi possível iniciar o download.");
  }
}

function BoardRow({ board, onChanged }: { board: Board; onChanged: () => void }) {
  const [url, setUrl] = useState(board.googleReviewUrl ?? "");
  const [redirectCode, setRedirectCode] = useState<"301" | "302">(board.redirectCode);
  const [editing, setEditing] = useState(false);
  const update = trpc.boards.update.useMutation({
    onSuccess: () => { toast.success(`Placa ${board.slug} atualizada`); setEditing(false); onChanged(); },
    onError: error => toast.error(error.message),
  });
  const publicUrl = `${window.location.origin}/p/${board.slug}`;
  const dirty = url !== (board.googleReviewUrl ?? "") || redirectCode !== board.redirectCode;

  function save() {
    update.mutate({ id: board.id, googleReviewUrl: url || null, redirectCode });
  }

  return <tr className="group border-b border-[#E8EFED] last:border-0 hover:bg-[#F9FCFB]">
    <td className="py-4 pl-5 pr-3 align-top"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-[#EAF6F3] text-sm font-bold text-[#0A867A]">{board.slug}</span><div><p className="font-semibold text-[#102A33]">{board.name}</p><p className="mt-0.5 font-mono text-xs text-[#718087]">/p/{board.slug}</p></div></div></td>
    <td className="hidden py-4 pr-3 align-top lg:table-cell"><StatusPill status={board.status} /></td>
    <td className="min-w-[260px] py-4 pr-3 align-top">
      {editing ? <div><input value={url} onChange={event => setUrl(event.target.value)} placeholder="Cole o link de avaliação do Google" className="h-10 w-full rounded-lg border border-[#BFD1CD] bg-white px-3 text-sm outline-none transition focus:border-[#18B6A4] focus:ring-4 focus:ring-[#18B6A4]/10" /><p className="mt-1.5 text-xs text-[#718087]">Aceita links HTTPS do Google, g.page e Google Maps.</p></div> : board.googleReviewUrl ? <a href={board.googleReviewUrl} target="_blank" rel="noreferrer" className="inline-flex max-w-[300px] items-center gap-1 truncate text-sm font-medium text-[#087C70] hover:underline"><Link2 size={14} />{board.googleReviewUrl.replace(/^https?:\/\//, "")}</a> : <button onClick={() => setEditing(true)} className="text-sm font-semibold text-[#A56505] hover:underline">Adicionar destino do Google</button>}
    </td>
    <td className="hidden py-4 pr-3 align-top xl:table-cell">{editing ? <select value={redirectCode} onChange={event => setRedirectCode(event.target.value as "301" | "302")} className="h-9 rounded-lg border border-[#DCE6E4] bg-white px-2 text-sm font-medium text-[#334B54]"><option value="302">302 temporário</option><option value="301">301 permanente</option></select> : <span className="font-mono text-xs font-bold text-[#52666E]">HTTP {board.redirectCode}</span>}</td>
    <td className="py-4 pr-5 align-top"><div className="flex items-center justify-end gap-1">
      {editing ? <><button onClick={() => { setEditing(false); setUrl(board.googleReviewUrl ?? ""); setRedirectCode(board.redirectCode); }} className="rounded-lg px-2.5 py-2 text-sm font-semibold text-[#52666E] hover:bg-[#EEF4F2]">Cancelar</button><button disabled={!dirty || update.isPending} onClick={save} className="inline-flex h-9 items-center gap-1 rounded-lg bg-[#102A33] px-3 text-sm font-bold text-white hover:bg-[#183A46] disabled:opacity-50">{update.isPending ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}Salvar</button></> : <>
        <button title="Copiar link público" onClick={() => copyText(publicUrl, "Link público")} className="grid h-9 w-9 place-items-center rounded-lg text-[#52666E] hover:bg-[#EAF6F3] hover:text-[#087C70]"><Copy size={16} /></button>
      <button title="Baixar QR Code" onClick={() => void downloadProtected(`/api/qrcodes/${board.slug}.png`, `avalia-nfc-placa-${board.slug}.png`)} className="grid h-9 w-9 place-items-center rounded-lg text-[#52666E] hover:bg-[#EAF6F3] hover:text-[#087C70]"><QrCode size={17} /></button>
        <button title="Editar placa" onClick={() => setEditing(true)} className="grid h-9 w-9 place-items-center rounded-lg text-[#52666E] hover:bg-[#EEF4F2]"><MoreHorizontal size={18} /></button>
      </>}
    </div></td>
  </tr>;
}

function SettingsPanel({ settings, refresh }: { settings: Settings; refresh: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Settings>(settings);
  useEffect(() => setForm(settings), [settings]);
  const update = trpc.settings.update.useMutation({ onSuccess: () => { toast.success("Configurações atualizadas"); refresh(); }, onError: error => toast.error(error.message) });

  return <section className="overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-[0_10px_30px_rgba(16,42,51,.035)]"><button onClick={() => setOpen(!open)} className="flex w-full items-center justify-between px-5 py-4 text-left"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#F0F7F5] text-[#087C70]"><Settings2 size={18} /></span><div><h2 className="font-bold text-[#102A33]">Configurações de ativação</h2><p className="text-xs text-[#718087]">Defina o comportamento de placas ainda virgens.</p></div></div><ChevronDown className={`text-[#718087] transition ${open ? "rotate-180" : ""}`} size={19} /></button>
    {open && <div className="border-t border-[#E8EFED] px-5 py-5"><div className="grid gap-5 lg:grid-cols-2"><div><label className="mb-2 block text-sm font-bold text-[#334B54]">Ao ler uma placa virgem</label><div className="flex rounded-lg bg-[#EEF4F2] p-1"><button onClick={() => setForm({ ...form, virginMode: "message" })} className={`flex-1 rounded-md px-3 py-2 text-sm font-bold ${form.virginMode === "message" ? "bg-white text-[#102A33] shadow-sm" : "text-[#718087]"}`}>Mostrar mensagem</button><button onClick={() => setForm({ ...form, virginMode: "whatsapp" })} className={`flex-1 rounded-md px-3 py-2 text-sm font-bold ${form.virginMode === "whatsapp" ? "bg-white text-[#102A33] shadow-sm" : "text-[#718087]"}`}>Abrir WhatsApp</button></div></div><div><label className="mb-2 block text-sm font-bold text-[#334B54]">Código padrão para novas placas</label><select value={form.defaultRedirectCode} onChange={event => setForm({ ...form, defaultRedirectCode: event.target.value as "301" | "302" })} className="h-10 w-full rounded-lg border border-[#DCE6E4] bg-white px-3 text-sm"><option value="302">302 — temporário e editável</option><option value="301">301 — permanente</option></select></div><div className="lg:col-span-2">{form.virginMode === "whatsapp" ? <><label className="mb-2 block text-sm font-bold text-[#334B54]">WhatsApp de vendas</label><input value={form.salesWhatsapp ?? ""} onChange={event => setForm({ ...form, salesWhatsapp: event.target.value })} placeholder="5511999999999 ou https://wa.me/..." className="h-10 w-full rounded-lg border border-[#DCE6E4] px-3 text-sm outline-none focus:border-[#18B6A4]" /></> : <><label className="mb-2 block text-sm font-bold text-[#334B54]">Mensagem apresentada</label><textarea value={form.virginMessage} onChange={event => setForm({ ...form, virginMessage: event.target.value })} rows={3} className="w-full rounded-lg border border-[#DCE6E4] p-3 text-sm outline-none focus:border-[#18B6A4]" /></>}</div></div><div className="mt-5 flex justify-end"><button disabled={update.isPending} onClick={() => update.mutate(form)} className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#18B6A4] px-4 text-sm font-bold text-[#062B29] hover:bg-[#28C7B5] disabled:opacity-60">{update.isPending && <Loader2 size={15} className="animate-spin" />}Salvar configurações</button></div></div>}
  </section>;
}

export default function Home() {
  const { user, loading, logout, login, loginError } = useAuth();
  const [masterPassword, setMasterPassword] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);
  const isAdmin = user?.role === "admin";
  const utils = trpc.useUtils();
  const boardsQuery = trpc.boards.list.useQuery(undefined, { enabled: Boolean(isAdmin) });
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: Boolean(isAdmin) });
  const create = trpc.boards.create.useMutation({ onSuccess: board => { toast.success(`${board.name} criada`); void boardsQuery.refetch(); }, onError: error => toast.error(error.message) });
  const [search, setSearch] = useState("");
  const boards = boardsQuery.data as Board[] | undefined;
  const filtered = useMemo(() => (boards ?? []).filter(board => `${board.name} ${board.slug} ${board.googleReviewUrl ?? ""}`.toLowerCase().includes(search.toLowerCase())), [boards, search]);
  const total = boards?.length ?? 0;
  const active = boards?.filter(board => board.status === "active").length ?? 0;
  const activationRate = total ? Math.round((active / total) * 100) : 0;

  if (loading) return <div className="grid min-h-screen place-items-center bg-[#F5F7F6]"><Loader2 className="animate-spin text-[#18B6A4]" size={28} /></div>;
  if (!user) return <main className="grid min-h-screen place-items-center bg-[#F5F7F6] p-6"><section className="w-full max-w-md rounded-3xl border border-[#DCE6E4] bg-white p-8 shadow-[0_18px_60px_rgba(16,42,51,.09)]"><BrandMark /><p className="mt-7 text-xs font-extrabold uppercase tracking-[.18em] text-[#0A867A]">Gestão de avaliações</p><h1 className="mt-3 text-3xl font-bold tracking-tight text-[#102A33]">Acesse o painel Avalia NFC</h1><p className="mt-3 leading-6 text-[#64747B]">Digite a senha mestre para criar placas, ativar destinos do Google e preparar os QR Codes para a gráfica.</p><form onSubmit={async event => { event.preventDefault(); setLoggingIn(true); try { await login(masterPassword); setMasterPassword(""); } catch {} finally { setLoggingIn(false); } }} className="mt-7"><label htmlFor="master-password" className="mb-2 block text-sm font-bold text-[#334B54]">Senha mestre</label><input id="master-password" type="password" autoComplete="current-password" value={masterPassword} onChange={event => setMasterPassword(event.target.value)} className="h-11 w-full rounded-xl border border-[#DCE6E4] px-3 outline-none focus:border-[#18B6A4] focus:ring-4 focus:ring-[#18B6A4]/10" autoFocus />{loginError && <p className="mt-2 text-sm font-semibold text-[#B04A38]">{loginError}</p>}<button disabled={loggingIn || !masterPassword} className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#102A33] font-bold text-white transition hover:bg-[#183A46] disabled:cursor-not-allowed disabled:opacity-60">{loggingIn ? <Loader2 size={18} className="animate-spin" /> : <ShieldCheck size={18} />}Entrar no painel</button></form></section></main>;
  if (!isAdmin) return <main className="grid min-h-screen place-items-center bg-[#F5F7F6] p-6"><section className="max-w-md rounded-3xl border border-[#F0DBB6] bg-white p-8 text-center"><AlertCircle className="mx-auto text-[#E4A83A]" size={32} /><h1 className="mt-4 text-2xl font-bold text-[#102A33]">Acesso administrativo necessário</h1><p className="mt-2 text-[#64747B]">Sua conta está autenticada, mas ainda não possui permissão de administração neste painel.</p><button onClick={() => logout()} className="mt-6 font-bold text-[#087C70]">Sair da conta</button></section></main>;

  return <main className="min-h-screen bg-[#F5F7F6] text-[#102A33]"><header className="border-b border-[#DCE6E4] bg-white"><div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8"><div className="flex items-center gap-3"><BrandMark /><div><div className="flex items-center gap-2"><span className="text-lg font-extrabold tracking-tight">Avalia NFC</span><span className="rounded bg-[#EAF6F3] px-1.5 py-0.5 text-[10px] font-extrabold tracking-wider text-[#087C70]">PAINEL</span></div><p className="text-xs text-[#718087]">Avaliações que começam no toque</p></div></div><div className="flex items-center gap-2"><span className="hidden text-sm font-medium text-[#52666E] sm:block">{user.name || "Administrador"}</span><button onClick={() => logout()} title="Sair" className="grid h-9 w-9 place-items-center rounded-lg text-[#64747B] hover:bg-[#F1F5F4]"><LogOut size={17} /></button></div></div></header>
    <div className="mx-auto max-w-[1440px] px-5 py-8 sm:px-8"><section className="mb-7 grid gap-5 xl:grid-cols-[1.5fr_1fr]"><div><p className="inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-[.15em] text-[#0A867A]"><Radio size={14} />Central de placas</p><h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">Cada toque, um destino certo.</h1><p className="mt-2 max-w-2xl text-[#64747B]">Crie, ative e prepare seus QR Codes dinâmicos sem perder o controle de cada placa física.</p></div><div className="rounded-2xl bg-[#102A33] p-5 text-white shadow-[0_14px_32px_rgba(16,42,51,.16)]"><div className="flex items-center justify-between"><p className="text-sm font-semibold text-[#C9DFDA]">Cobertura ativa</p><Sparkles size={17} className="text-[#18B6A4]" /></div><div className="mt-2 flex items-end justify-between"><span className="text-4xl font-bold tracking-tight">{activationRate}%</span><span className="text-sm text-[#C9DFDA]">{active} de {total} placas</span></div><div className="mt-4 flex gap-1">{Array.from({ length: 10 }).map((_, index) => <span key={index} className={`h-1.5 flex-1 rounded-full ${index < Math.ceil(activationRate / 10) ? "bg-[#18B6A4]" : "bg-white/15"}`} />)}</div></div></section>
      <section className="grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border border-[#DCE6E4] bg-white p-5"><p className="text-sm font-medium text-[#718087]">Placas cadastradas</p><p className="mt-1 text-3xl font-bold">{total}</p></div><div className="rounded-2xl border border-[#DCE6E4] bg-white p-5"><p className="text-sm font-medium text-[#718087]">Prontas para avaliar</p><p className="mt-1 text-3xl font-bold text-[#087C70]">{active}</p></div><div className="rounded-2xl border border-[#DCE6E4] bg-white p-5"><p className="text-sm font-medium text-[#718087]">Aguardando ativação</p><p className="mt-1 text-3xl font-bold text-[#A56505]">{total - active}</p></div></section>
      <section className="mt-7 overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-[0_10px_30px_rgba(16,42,51,.035)]"><div className="flex flex-col gap-4 border-b border-[#E8EFED] p-5 lg:flex-row lg:items-center lg:justify-between"><div><div className="flex items-center gap-2"><h2 className="text-lg font-bold">Suas placas</h2><span className="rounded-full bg-[#EEF4F2] px-2 py-0.5 text-xs font-bold text-[#52666E]">{total}</span></div><p className="mt-1 text-sm text-[#718087]">O QR aponta para /p/código e usa o destino salvo quando for escaneado.</p></div><div className="flex flex-wrap gap-2"><button onClick={() => void downloadProtected("/api/qrcodes.zip", "avalia-nfc-qrcodes.zip")} className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#C9D9D5] px-3 text-sm font-bold text-[#334B54] hover:bg-[#F3F8F7]"><Download size={16} />ZIP em lote</button><button onClick={() => void downloadProtected("/api/qrcodes.pdf?includeVirgin=1", "avalia-nfc-qrcodes-grafica.pdf")} className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#C9D9D5] px-3 text-sm font-bold text-[#334B54] hover:bg-[#F3F8F7]"><FileText size={16} />PDF gráfica</button><button onClick={() => void downloadProtected("/api/qrcodes.pdf?includeVirgin=1&theme=blue-black", "avalia-nfc-qrcodes-azul-preto.pdf")} className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#1C5FD4] px-3 text-sm font-bold text-[#1451B8] hover:bg-[#EEF5FF]"><FileText size={16} />PDF azul + preto</button><button onClick={() => void downloadProtected("/api/qrcodes.pdf?includeVirgin=1&theme=blue", "avalia-nfc-qrcodes-azul.pdf")} className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#1D4ED8] bg-[#1746A2] px-3 text-sm font-bold text-white hover:bg-[#123A8A]"><FileText size={16} />PDF azul</button><button disabled={create.isPending} onClick={() => create.mutate()} className="inline-flex h-10 items-center gap-2 rounded-lg bg-[#18B6A4] px-4 text-sm font-extrabold text-[#062B29] hover:bg-[#28C7B5] disabled:opacity-60">{create.isPending ? <Loader2 size={16} className="animate-spin" /> : <Plus size={17} />}Nova placa</button></div></div>
        <div className="flex flex-col gap-3 border-b border-[#E8EFED] bg-[#FBFDFC] px-5 py-3 sm:flex-row sm:items-center sm:justify-between"><label className="relative block w-full sm:w-[340px]"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#718087]" /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Buscar por placa, código ou link" className="h-10 w-full rounded-lg border border-[#DCE6E4] bg-white pl-9 pr-3 text-sm outline-none focus:border-[#18B6A4]" /></label><p className="inline-flex items-center gap-1.5 text-xs text-[#718087]"><CircleHelp size={14} />Use 302 enquanto o destino pode mudar.</p></div>
        {boardsQuery.isLoading ? <div className="grid min-h-64 place-items-center"><Loader2 className="animate-spin text-[#18B6A4]" /></div> : boardsQuery.isError ? <div className="p-8 text-center"><AlertCircle className="mx-auto text-[#E4A83A]" /><p className="mt-2 font-bold">Não foi possível carregar as placas.</p><button onClick={() => boardsQuery.refetch()} className="mt-3 text-sm font-bold text-[#087C70]">Tentar novamente</button></div> : <><div className="hidden overflow-x-auto md:block"><table className="w-full text-left"><thead className="bg-[#FBFDFC] text-xs uppercase tracking-wider text-[#718087]"><tr><th className="px-5 py-3 font-bold">Placa</th><th className="hidden py-3 pr-3 font-bold lg:table-cell">Estado</th><th className="py-3 pr-3 font-bold">Destino de avaliação</th><th className="hidden py-3 pr-3 font-bold xl:table-cell">Redirecionamento</th><th className="px-5 py-3 text-right font-bold">Ações</th></tr></thead><tbody>{filtered.map(board => <BoardRow key={board.id} board={board} onChanged={() => void boardsQuery.refetch()} />)}</tbody></table></div><div className="divide-y divide-[#E8EFED] md:hidden">{filtered.map(board => <div key={board.id} className="p-5"><div className="flex items-start justify-between"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-[#EAF6F3] text-sm font-bold text-[#0A867A]">{board.slug}</span><div><p className="font-bold">{board.name}</p><p className="font-mono text-xs text-[#718087]">/p/{board.slug}</p></div></div><StatusPill status={board.status} /></div><p className="mt-4 truncate text-sm text-[#52666E]">{board.googleReviewUrl || "Nenhum destino configurado"}</p><div className="mt-4 flex gap-2"><button onClick={() => copyText(`${window.location.origin}/p/${board.slug}`, "Link público")} className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-[#DCE6E4] px-3 text-sm font-bold"><Copy size={14} />Copiar</button><button onClick={() => void downloadProtected(`/api/qrcodes/${board.slug}.png`, `avalia-nfc-placa-${board.slug}.png`)} className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-[#DCE6E4] px-3 text-sm font-bold"><QrCode size={14} />QR</button></div></div>)}</div>{filtered.length === 0 && <div className="p-12 text-center"><QrCode className="mx-auto text-[#9DADAE]" size={28} /><p className="mt-3 font-bold">{total ? "Nenhuma placa encontrada" : "Ainda não há placas cadastradas"}</p><p className="mt-1 text-sm text-[#718087]">{total ? "Tente outro termo de busca." : "Crie a primeira placa para começar."}</p></div>}</>}
      </section>
      {settingsQuery.data && <div className="mt-7"><SettingsPanel settings={settingsQuery.data as Settings} refresh={() => { void settingsQuery.refetch(); void utils.settings.get.invalidate(); }} /></div>}
      <footer className="flex flex-col gap-2 py-7 text-xs text-[#718087] sm:flex-row sm:items-center sm:justify-between"><span>© {new Date().getFullYear()} Avalia NFC • QR Codes dinâmicos</span><a href="https://www.google.com/business/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-[#52666E] hover:text-[#087C70]">Sobre avaliações do Google <ArrowUpRight size={13} /></a></footer>
    </div>
  </main>;
}
