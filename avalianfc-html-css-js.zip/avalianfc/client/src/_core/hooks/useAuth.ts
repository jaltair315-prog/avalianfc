import { useCallback, useEffect, useState } from "react";

type AuthUser = {
  name: string;
  email?: string | null;
  role: "admin";
};

type UseAuthState = {
  user: AuthUser | null;
  loading: boolean;
  error: Error | null;
  loginError: string | null;
  login: (password: string) => Promise<void>;
  logout: () => Promise<void>;
};

export function useAuth(): UseAuthState {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/master/me", { credentials: "include" });
      if (!response.ok) {
        setUser(null);
        return;
      }
      const body = await response.json() as { user?: AuthUser };
      setUser(body.user ?? null);
    } catch (cause) {
      setError(cause instanceof Error ? cause : new Error("Não foi possível verificar a sessão."));
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const login = useCallback(async (password: string) => {
    setLoginError(null);
    const response = await fetch("/api/master/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ password }),
    });
    const body = await response.json().catch(() => ({})) as { error?: string; user?: AuthUser };
    if (!response.ok) {
      const message = body.error ?? "Não foi possível entrar no painel.";
      setLoginError(message);
      throw new Error(message);
    }
    setUser(body.user ?? null);
  }, []);

  const logout = useCallback(async () => {
    await fetch("/api/master/logout", { method: "POST", credentials: "include" });
    setUser(null);
  }, []);

  return { user, loading, error, loginError, login, logout };
}
