# Plano de implementação — Avalia NFC

## Objetivo

Entregar uma base funcional de produção para a Avalia NFC gerenciar placas NFC/QR Code que apontam para links de avaliação do Google. Cada placa terá um slug sequencial (`/p/01`, `/p/02`...), estado `Virgem` ou `Ativa`, destino configurável e QR Code baixável. O painel será em português do Brasil.

## Arquitetura escolhida

**SPA React + TypeScript no frontend, Express no backend, tRPC para a API interna e MySQL gerenciado via Drizzle ORM.** O Express serve a aplicação Vite em desenvolvimento e os arquivos compilados em produção. O mesmo domínio atende o painel, a API `/api/trpc/*`, a saúde `/api/health` e o redirecionamento público `/p/:slug`.

Por que esta opção: o cadastro e edição precisam de persistência, autenticação e resposta imediata, mas não precisam de SSR. A SPA mantém a primeira carga pequena e deixa os dados privados sob controle das procedures protegidas. O redirecionamento público é uma rota Express direta, sem passar pela SPA.

### Alternativas consideradas

| Abordagem | Tradeoffs | Custo | Complexidade de setup |
| --- | --- | --- | --- |
| React/TypeScript + Express + banco gerenciado (escolhida) | Mais flexível, CRUD seguro, QR em lote e evolução futura; exige deploy e configuração inicial | Baixo/uso conforme volume; banco já gerenciado no projeto | Média |
| WordPress + plugin/custom post type | Mais simples para quem já tem WordPress e hospedagem; plugins de QR e segurança podem conflitar e o redirecionamento exige cuidado | Baixo se o WordPress já existir; custo de hospedagem/plugins varia | Baixa a média |
| Planilha/links estáticos | Quase zero de custo; não oferece painel seguro, geração em lote confiável ou redirecionamento dinâmico robusto | Mínimo | Baixa, mas não atende produção |

## Estrutura do produto

- `client/src/pages/Home.tsx`: dashboard principal com métricas e lista de placas.
- `client/src/components/`: componentes visuais reutilizáveis do starter.
- `client/src/index.css`: tokens visuais, responsividade e estados de interação.
- `server/routers.ts`: procedures protegidas para placas, configurações e downloads; procedures públicas para leitura do destino da placa.
- `server/db.ts`: queries Drizzle e criação inicial da próxima sequência.
- `server/_core/index.ts`: health check, OAuth, tRPC, rota HTTP pública `/p/:slug` e fallback estático.
- `drizzle/schema.ts`: tabelas `users`, `boards` e `appSettings`.
- `drizzle/*.sql`: migrations versionadas.
- `public/manus-routes.json`: manifesto das rotas do frontend.
- `docs/IMPLEMENTACAO.md`: guia de banco, domínio, segurança, rotas e deploy em português.

## Modelo de dados

### `users`
Tabela do starter para Manus OAuth. `role` é usado para permitir apenas administradores do painel.

### `boards`

- `id`: inteiro autoincrementado.
- `sequence`: inteiro único e crescente.
- `slug`: varchar único no formato `01`, `02`, ...; calculado pela sequência.
- `name`: nome exibido, por exemplo `Placa 01`.
- `googleReviewUrl`: link de avaliação do Google; nulo quando Virgem.
- `status`: enum `virgin`/`active` derivado do link salvo.
- `redirectCode`: enum `302`/`301` por placa, com padrão `302`.
- `createdAt`, `updatedAt`.

### `appSettings`
Registro único de configurações operacionais:

- `id`: chave primária fixa `1`.
- `virginMode`: `whatsapp` ou `message`.
- `salesWhatsapp`: número/URL de WhatsApp da Avalia NFC.
- `virginMessage`: mensagem padrão de placa não ativada.
- `defaultRedirectCode`: `302` ou `301`.
- `updatedAt`.

## Regras de negócio

1. A criação de uma placa usa a maior sequência existente + 1 dentro de uma transação/fluxo protegido e gera slug com `padStart(2, '0')`.
2. Placa sem `googleReviewUrl` fica `Virgem`.
3. URL salva deve ser HTTPS e pertencer a um domínio esperado do Google (`google.com`, `g.page`, `maps.app.goo.gl`, `search.google.com` ou subdomínios). O sistema não aceita `javascript:`, HTTP ou destinos arbitrários.
4. O redirecionamento público não revela dados do cliente. Para placa ativa, retorna `301` ou `302` conforme a placa. Para placa virgem em modo WhatsApp, retorna o destino configurado; no modo mensagem, serve uma página HTML curta com status `200`.
5. O painel exige sessão Manus OAuth válida e bloqueia usuários sem role `admin`.
6. QR individual aponta sempre para o URL público relativo da placa; o lote gera PNGs e ZIP no servidor usando `qrcode`/`archiver` e inclui um `LEIA-ME.txt` com a origem dos arquivos. A exportação PDF organiza QR Codes em folha A4 com identificação.

## API e rotas

### tRPC protegido

- `boards.list`: lista placas ordenadas por sequência.
- `boards.create`: cria próxima placa.
- `boards.update`: atualiza link, código e nome; valida URL e recalcula status.
- `boards.delete`: remove uma placa somente para manutenção administrativa.
- `boards.getSettings`: lê configurações.
- `boards.updateSettings`: grava modo virgem, WhatsApp, mensagem e código padrão.
- `boards.downloadZip`: gera resposta/arquivo para QR individual ou lote.
- `boards.downloadPdf`: gera PDF consolidado.

### HTTP

- `GET /p/:slug`: procura placa, aplica regra virgem/ativa e redireciona imediatamente com `Cache-Control: no-store`.
- `GET /api/health`: resposta pública de saúde.
- `GET /api/platform/config.js`: configuração pública exigida pelo starter.
- `client/public/manus-routes.json`: manifesto de páginas do frontend.

## Frontend e experiência

O dashboard terá navegação simples: cabeçalho de marca, resumo de placas, ação de criar, busca/filtro e tabela responsiva. Cada linha mostra o estado, slug, destino, edição inline, cópia do link público e download do QR. Um painel de configurações cobre o comportamento das placas virgens e o código de redirecionamento. Feedbacks serão exibidos via toasts.

A direção visual usa azul petróleo escuro, ciano de sinal e âmbar para a atenção de placas virgens, sobre fundo marfim claro. A linguagem visual evita aparência de template genérico: status em pílulas, pequenos marcadores de sinal, tabela com hierarquia forte e um bloco de resumo com “cobertura ativa”.

## Segurança

- Manus OAuth e cookie `webdev_app_session` do starter.
- `protectedProcedure` + verificação de `ctx.user.role === 'admin'`.
- Validação server-side com Zod em todas as entradas.
- Escapamento de texto no HTML de placa virgem.
- Allowlist de URL Google e bloqueio de protocolos perigosos.
- Sem dados privados no redirecionamento; respostas do painel com `private, no-store`.
- Sem cache compartilhado para `/api/*` e `/p/*` porque o destino pode ser alterado.

## Deployment e domínio

A produção usa o Dockerfile existente, com `pnpm build` no build e `node dist/index.js` no runtime. O frontend é CSR servido pelo Express e as rotas dinâmicas vão ao mesmo container. A configuração publicada deve declarar o servidor e as rotas com `/api/*`, `/p/*` e o catch-all SPA. Assets com hash podem usar cache imutável; HTML, API e redirecionamentos devem ser `no-cache`/`no-store`.

Depois de publicar, apontar `aval ia nfc.com.br`/domínio real para a URL do projeto, ativar TLS e validar `https://dominio/p/01`, o callback OAuth e o QR impresso. A configuração de WhatsApp e o primeiro usuário administrador devem ser feitos no painel após o login.

## Verificação

- `pnpm check` para tipos.
- `pnpm test` para testes existentes e novos testes da lógica de URL/status/redirecionamento.
- `pnpm build` para validar compilação frontend/backend.
- `curl`/health check local para `/api/health`, `/manus-routes.json` e `/p/01` quando houver dados de seed.
- Inspeção de contrato entre respostas tRPC e os tipos consumidos pelo frontend.
