CREATE TABLE `appSettings` (
	`id` int NOT NULL,
	`virginMode` enum('whatsapp','message') NOT NULL DEFAULT 'message',
	`salesWhatsapp` varchar(255),
	`virginMessage` text NOT NULL,
	`defaultRedirectCode` enum('301','302') NOT NULL DEFAULT '302',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `boards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sequence` int NOT NULL,
	`slug` varchar(32) NOT NULL,
	`name` varchar(120) NOT NULL,
	`googleReviewUrl` varchar(2048),
	`status` enum('virgin','active') NOT NULL DEFAULT 'virgin',
	`redirectCode` enum('301','302') NOT NULL DEFAULT '302',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `boards_id` PRIMARY KEY(`id`),
	CONSTRAINT `boards_sequence_unique` UNIQUE(`sequence`),
	CONSTRAINT `boards_slug_unique` UNIQUE(`slug`)
);
