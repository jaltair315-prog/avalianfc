import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing the Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const boards = mysqlTable("boards", {
  id: int("id").autoincrement().primaryKey(),
  sequence: int("sequence").notNull().unique(),
  slug: varchar("slug", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  googleReviewUrl: varchar("googleReviewUrl", { length: 2048 }),
  status: mysqlEnum("status", ["virgin", "active"]).default("virgin").notNull(),
  redirectCode: mysqlEnum("redirectCode", ["301", "302"]).default("302").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const appSettings = mysqlTable("appSettings", {
  id: int("id").primaryKey(),
  virginMode: mysqlEnum("virginMode", ["whatsapp", "message"]).default("message").notNull(),
  salesWhatsapp: varchar("salesWhatsapp", { length: 255 }),
  virginMessage: text("virginMessage").notNull(),
  defaultRedirectCode: mysqlEnum("defaultRedirectCode", ["301", "302"]).default("302").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Board = typeof boards.$inferSelect;
export type InsertBoard = typeof boards.$inferInsert;
export type AppSettings = typeof appSettings.$inferSelect;
export type InsertAppSettings = typeof appSettings.$inferInsert;
