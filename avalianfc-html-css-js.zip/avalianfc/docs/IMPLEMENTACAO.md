# Avalia NFC — implementação e operação

> **Objetivo:** manter placas NFC/QR Code estáveis mesmo quando o cliente muda seu link de avaliação. O QR impresso aponta para `/p/NN`; o destino Google pode ser alterado no painel sem reimpressão.

## Solução recomendada

A base entregue usa **React + TypeScript + Express + MySQL gerenciado**. É a escolha indicada quando há centenas ou milhares de placas, necessidade de acesso administrativo, QR em lote e troca instantânea de destinos. O painel é uma SPA; o Express responde a API e ao redirecionamento público. Não há dependência de serviços externos na leitura da placa.

| Alternativa | Quando é adequada | Vantagens | Limitações |
| --- | --- | --- | --- |
| React/Express/MySQL (esta base) | Operação própria, crescimento e QR em lote | Controle de regras, banco, API e segurança | Requer deploy inicial e domínio configurado |
| WordPress + plugin/código customizado | Empresa já possui WordPress bem mantido | Familiaridade e menor curva inicial | Plugins, cache e segurança precisam de manutenção atenta |
| Links fixos | Piloto muito pequeno | Implementação mínima | Não permite mudar destino sem reimprimir; não é recomendado |

## Arquitetura e pastas

```text
client/src/pages/Home.tsx     Dashboard administrativo
server/routers.ts             CRUD tRPC protegido por administrador
server/publicRoutes.ts        GET /p/:slug e redirecionamento público
server/qrcodes.ts             PNG individual, ZIP e PDF A4
server/db.ts                  Queries, URLs permitidas e sequência
server/_core/index.ts         Servidor Express e composição de rotas
drizzle/schema.ts             Schema do MySQL
public/manus-routes.json      Manifesto de páginas do frontend
```

## Banco de dados

| Tabela | Uso | Campos principais |
| --- | --- | --- |
| `users` | Usuários autenticados pelo Manus OAuth | `openId`, `role`, `name`, `email` |
| `boards` | Uma linha por placa física | `sequence`, `slug`, `name`, `googleReviewUrl`, `status`, `redirectCode` |
| `appSettings` | Configuração única da operação | `virginMode`, `salesWhatsapp`, `virginMessage`, `defaultRedirectCode` |

O slug é criado sequencialmente usando `String(sequence).padStart(2, '0')`; assim as primeiras placas ficam em `01`, `02`, e continuam aumentando sem limite prático. `status` é `virgin` até que exista uma URL válida de avaliação Google; depois passa a `active`.

## Rotas principais

| Método/rota | Proteção | Comportamento |
| --- | --- | --- |
| `GET /p/:slug` | Pública | Placa ativa redireciona para Google; virgem abre WhatsApp configurado ou página de aviso |
| `GET /api/qrcodes/:slug.png` | Administrador | Baixa QR individual PNG |
| `GET /api/qrcodes.zip` | Administrador | Baixa todos os QR Codes em ZIP; suporta `?slugs=01,02` |
| `GET /api/qrcodes.pdf` | Administrador | PDF A4 com seis QR Codes por página |
| `/api/trpc/boards.*` | Administrador | Listar, criar, editar e remover placas |
| `/api/trpc/settings.*` | Administrador | Ler e alterar comportamento de placa virgem |
| `GET /api/health` | Pública | Health check do deploy |

### Redirecionamento

Use **302** como padrão quando um destino ainda pode ser alterado. Use **301** somente para um destino estável: alguns navegadores e caches podem memorizar o redirecionamento permanente. Toda resposta `/p/:slug` envia `Cache-Control: no-store` para reduzir risco de cache intermediário, mas 301 ainda é uma decisão de longo prazo do cliente.

O backend só aceita destinos HTTPS nos domínios `google.com`, `g.page`, `maps.app.goo.gl` e `search.google.com` (incluindo subdomínios). Isso evita que o painel se transforme em um encurtador de links aberto.

## Configuração inicial

1. No diretório do projeto, aplique as migrations: `pnpm db:push`.
2. Inicie localmente: `pnpm dev`.
3. Abra o painel e informe a senha mestre no formulário inicial. A variável protegida `MASTER_PASSWORD` é validada somente no servidor e cria um cookie HTTP-only com expiração de 7 dias. O OAuth Manus permanece disponível apenas no backend legado, mas não é mais exigido pela interface.
4. Em **Configurações de ativação**, escolha se a placa virgem abre uma mensagem ou o WhatsApp de vendas.
5. Crie uma placa. Ela começa como `Placa 01` e URL pública `/p/01`.
6. Copie e guarde a URL pública. Cole apenas essa URL no layout/QR da gráfica. No painel, cole o link de avaliação Google quando o cliente for ativado.

## Domínio e QR pronto para impressão

Antes da primeira impressão em escala, defina a variável protegida de produção:

```text
PUBLIC_BASE_URL=https://avalianfc.com.br
```

O gerador de QR usa esse endereço (com fallback para `https://avalianfc.com.br`). Depois, associe o domínio no serviço de hospedagem, configure o DNS exatamente como solicitado pelo provedor, espere o TLS ficar ativo e valide com um celular em rede móvel:

1. `https://avalianfc.com.br/p/01` abre a página virgem ou WhatsApp.
2. Após salvar um link Google, o mesmo endereço redireciona para a página correta.
3. O PNG baixado no painel abre esse mesmo endereço no leitor de QR.
4. O PDF A4 tem identificação visível de cada placa antes do envio à gráfica.

Não use URLs de Preview ou localhost em material impresso. Se o domínio for alterado no futuro, mantenha o domínio antigo respondendo e redirecione-o para o novo domínio; do contrário, QR Codes já entregues deixam de funcionar.

## Segurança operacional

- O painel usa senha mestre, sessão HTTP-only e procedures de administrador; sem a sessão válida não é possível gerenciar placas nem baixar QR Codes.
- Se aparecer “Senha mestre incorreta”, confira o valor configurado em `MASTER_PASSWORD`. A senha não deve ser colocada no frontend, em arquivos Git ou em mensagens.
- `webdev_app_session` é o cookie da aplicação do starter; não o renomeie.
- Não coloque segredos em `client/src` nem em commits. Use o painel seguro de variáveis do ambiente para `PUBLIC_BASE_URL` e qualquer futuro segredo.
- URLs são validadas no servidor e não apenas no navegador.
- O redirecionamento público não entrega dados de clientes; somente consulta a placa e responde com o destino necessário.
- Faça backup exportando a tabela `boards` antes de ações destrutivas. A remoção de placas não deve ser exposta a operadores comuns.

## Desenvolvimento e validação

```bash
pnpm check       # TypeScript
pnpm test        # Testes existentes e de regras
pnpm build       # Build React + Express
pnpm db:push     # Gerar/aplicar migration após alterações de schema
pnpm dev         # Desenvolvimento local na porta configurada
```

Antes de publicar, execute `pnpm check`, `pnpm test` e `pnpm build`. Em produção, mantenha `/api/*` e `/p/*` no servidor, e não aplique cache compartilhado a essas rotas. Assets versionados podem ser cacheados por longo período; HTML e dados do painel devem permanecer privados ou revalidáveis.

## Evoluções sugeridas

A base está pronta para evoluir com importação CSV, etiqueta com nome do cliente, usuários com papel `operador`, trilha de alterações e relatórios agregados de scans. Para contagem de leituras, adicione uma tabela de eventos com retenção e aviso de privacidade antes de registrar IP, localização ou identificadores do dispositivo.
