import crypto from "node:crypto";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import type { User } from "../../drizzle/schema";
import { ENV } from "./env";
import { getSessionCookieOptions } from "./cookies";

export const MASTER_COOKIE_NAME = "avalia_nfc_master";
const MASTER_SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;

export function masterUser(): User {
  const now = new Date();
  return {
    id: 0,
    openId: "master-password",
    name: "Administrador",
    email: null,
    loginMethod: "master-password",
    role: "admin",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  };
}

function sign(value: string) {
  return crypto.createHmac("sha256", ENV.masterPassword).update(value).digest("hex");
}

function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createToken() {
  const expiresAt = Date.now() + MASTER_SESSION_TTL_MS;
  const payload = String(expiresAt);
  return `${payload}.${sign(payload)}`;
}

export function isMasterAuthenticated(req: Request) {
  if (!ENV.masterPassword) return false;
  const raw = parseCookieHeader(req.headers.cookie ?? "")[MASTER_COOKIE_NAME];
  if (!raw) return false;
  const [expiresAt, signature] = raw.split(".");
  return Boolean(expiresAt && signature && Number(expiresAt) > Date.now() && safeEqual(signature, sign(expiresAt)));
}

export function registerMasterAuthRoutes(app: Express) {
  app.post("/api/master/login", (req, res) => {
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!ENV.masterPassword) {
      res.status(503).json({ error: "A senha mestre ainda não foi configurada." });
      return;
    }
    if (!safeEqual(password, ENV.masterPassword)) {
      res.status(401).json({ error: "Senha mestre incorreta." });
      return;
    }
    res.cookie(MASTER_COOKIE_NAME, createToken(), { ...getSessionCookieOptions(req), maxAge: MASTER_SESSION_TTL_MS });
    res.json({ user: masterUser() });
  });

  app.get("/api/master/me", (req, res) => {
    if (!isMasterAuthenticated(req)) {
      res.status(401).json({ authenticated: false });
      return;
    }
    res.json({ authenticated: true, user: masterUser() });
  });

  app.post("/api/master/logout", (req, res) => {
    res.clearCookie(MASTER_COOKIE_NAME, { ...getSessionCookieOptions(req), maxAge: -1 });
    res.json({ success: true });
  });
}
