import { describe, expect, it } from "vitest";

describe("graphics PDF themes", () => {
  it("uses the blue-black theme query and filename", () => {
    const url = "/api/qrcodes.pdf?includeVirgin=1&theme=blue-black";
    const params = new URL(url, "https://avalianfc.com.br").searchParams;
    expect(params.get("includeVirgin")).toBe("1");
    expect(params.get("theme")).toBe("blue-black");
    expect("avalia-nfc-qrcodes-azul-preto.pdf").toContain("azul-preto");
  });

  it("uses the blue-only theme and filename", () => {
    const url = "/api/qrcodes.pdf?includeVirgin=1&theme=blue";
    const params = new URL(url, "https://avalianfc.com.br").searchParams;
    expect(params.get("theme")).toBe("blue");
    expect("avalia-nfc-qrcodes-azul.pdf").toContain("azul");
  });
});
