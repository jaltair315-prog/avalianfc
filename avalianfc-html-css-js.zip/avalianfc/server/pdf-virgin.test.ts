import { describe, expect, it } from "vitest";

describe("PDF gráfica export", () => {
  it("uses an explicit flag to include virgin boards", () => {
    const url = "/api/qrcodes.pdf?includeVirgin=1";
    expect(new URL(url, "https://avalianfc.com.br").searchParams.get("includeVirgin")).toBe("1");
  });
});
