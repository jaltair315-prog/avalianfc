import express from "express";
import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getBoardBySlug: vi.fn(),
  getSettings: vi.fn(),
}));

import * as db from "./db";
import { registerPublicBoardRoutes } from "./publicRoutes";

const board = {
  id: 1,
  sequence: 1,
  slug: "01",
  name: "Placa 01",
  googleReviewUrl: "https://g.page/r/example/review",
  status: "active" as const,
  redirectCode: "302" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const settings = {
  id: 1,
  virginMode: "message" as const,
  salesWhatsapp: null,
  virginMessage: "Esta placa ainda não foi ativada. Entre em contato com a Avalia NFC.",
  defaultRedirectCode: "302" as const,
  updatedAt: new Date(),
};

let currentServer: ReturnType<express.Express["listen"]> | undefined;

afterEach(async () => {
  vi.clearAllMocks();
  if (currentServer?.listening) {
    await new Promise<void>(resolve => currentServer!.close(() => resolve()));
  }
  currentServer = undefined;
});

async function requestPublic(path: string) {
  const app = express();
  registerPublicBoardRoutes(app);
  currentServer = app.listen(0);
  await new Promise<void>(resolve => currentServer!.once("listening", () => resolve()));
  const port = (currentServer.address() as AddressInfo).port;
  return fetch(`http://127.0.0.1:${port}${path}`, { redirect: "manual" });
}

describe("public board redirect route", () => {
  it("returns the current active Google target using the selected temporary redirect", async () => {
    vi.mocked(db.getBoardBySlug).mockResolvedValue(board);
    const response = await requestPublic("/p/01");
    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe(board.googleReviewUrl);
    expect(response.headers.get("cache-control")).toContain("no-store");
  });

  it("honors a permanent redirect when the board requests 301", async () => {
    vi.mocked(db.getBoardBySlug).mockResolvedValue({ ...board, redirectCode: "301" });
    const response = await requestPublic("/p/01");
    expect(response.status).toBe(301);
  });

  it("renders the configured message for a virgin board", async () => {
    vi.mocked(db.getBoardBySlug).mockResolvedValue({ ...board, googleReviewUrl: null, status: "virgin" });
    vi.mocked(db.getSettings).mockResolvedValue(settings);
    const response = await requestPublic("/p/01");
    expect(response.status).toBe(200);
    expect(await response.text()).toContain(settings.virginMessage);
  });

  it("sends a virgin board to configured WhatsApp sales", async () => {
    vi.mocked(db.getBoardBySlug).mockResolvedValue({ ...board, googleReviewUrl: null, status: "virgin" });
    vi.mocked(db.getSettings).mockResolvedValue({ ...settings, virginMode: "whatsapp", salesWhatsapp: "https://wa.me/5511999999999" });
    const response = await requestPublic("/p/01");
    expect(response.status).toBe(302);
    expect(response.headers.get("location")).toBe("https://wa.me/5511999999999");
  });

  it("does not cache missing public board responses", async () => {
    vi.mocked(db.getBoardBySlug).mockResolvedValue(undefined);
    const response = await requestPublic("/p/99");
    expect(response.status).toBe(404);
    expect(response.headers.get("cache-control")).toContain("no-store");
  });
});
