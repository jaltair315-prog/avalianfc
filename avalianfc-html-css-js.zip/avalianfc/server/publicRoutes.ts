import type { Express } from "express";
import * as db from "./db";

function escapeHtml(value: string) {
  return value.replace(/[&<>'\"]/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
  })[character] ?? character);
}

function virginPage(message: string) {
  const safeMessage = escapeHtml(message);
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Placa ainda não ativada | Avalia NFC</title><style>body{margin:0;background:#f5f7f6;color:#102a33;font-family:Arial,sans-serif;display:grid;min-height:100vh;place-items:center}.card{max-width:460px;margin:24px;padding:32px;border:1px solid #dce6e4;border-radius:16px;background:white;box-shadow:0 18px 48px #102a3314}.mark{color:#18b6a4;font-weight:800;letter-spacing:.08em;text-transform:uppercase;font-size:12px}h1{font-size:28px;margin:16px 0 12px}p{line-height:1.6;color:#52666e;margin:0}</style></head><body><main class="card"><div class="mark">Avalia NFC</div><h1>Placa ainda não ativada</h1><p>${safeMessage}</p></main></body></html>`;
}

export function registerPublicBoardRoutes(app: Express) {
  app.get("/p/:slug", async (req, res) => {
    res.set("Cache-Control", "no-store, max-age=0");
    const slug = req.params.slug;
    if (!/^\d{2,32}$/.test(slug)) {
      res.status(404).type("text/plain").send("Placa não encontrada.");
      return;
    }

    try {
      const board = await db.getBoardBySlug(slug);
      if (!board) {
        res.status(404).type("text/plain").send("Placa não encontrada.");
        return;
      }
      if (board.status === "active" && board.googleReviewUrl) {
        res.redirect(board.redirectCode === "301" ? 301 : 302, board.googleReviewUrl);
        return;
      }

      const settings = await db.getSettings();
      if (settings.virginMode === "whatsapp" && settings.salesWhatsapp) {
        res.redirect(302, settings.salesWhatsapp);
        return;
      }
      res.status(200).type("html").send(virginPage(settings.virginMessage));
    } catch (error) {
      console.error("[Public redirect]", error);
      res.status(503).type("text/plain").send("Serviço temporariamente indisponível.");
    }
  });
}
