import { describe, expect, it } from "vitest";

describe("horizontal graphics card layout", () => {
  it("keeps the dynamic QR on the left side of the landscape card", () => {
    const cardWidth = 250;
    const qrX = 31;
    const qrSize = 72;
    expect(qrX + qrSize).toBeLessThan(cardWidth / 2);
  });

  it("keeps the NFC/cellphone illustration on the right side", () => {
    const cardWidth = 250;
    const illustrationSide = "right";
    expect(illustrationSide).toBe("right");
    expect(cardWidth).toBeGreaterThan(0);
  });
});
