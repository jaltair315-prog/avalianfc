import { z } from "zod";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { MASTER_COOKIE_NAME } from "./_core/masterAuth";
import * as db from "./db";
import { systemRouter } from "./_core/systemRouter";

const redirectCodeSchema = z.enum(["301", "302"]);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(MASTER_COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  boards: router({
    list: adminProcedure.query(() => db.listBoards()),
    create: adminProcedure.mutation(async () => {
      const settings = await db.getSettings();
      return db.createBoard(settings.defaultRedirectCode);
    }),
    update: adminProcedure
      .input(z.object({
        id: z.number().int().positive(),
        name: z.string().min(2).max(120).optional(),
        googleReviewUrl: z.string().max(2048).nullable().optional(),
        redirectCode: redirectCodeSchema.optional(),
      }))
      .mutation(({ input }) => db.updateBoard(input)),
    remove: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.deleteBoard(input.id);
        return { success: true } as const;
      }),
  }),
  settings: router({
    get: adminProcedure.query(() => db.getSettings()),
    update: adminProcedure
      .input(z.object({
        virginMode: z.enum(["whatsapp", "message"]),
        salesWhatsapp: z.string().max(255).nullable().optional(),
        virginMessage: z.string().min(8).max(1000),
        defaultRedirectCode: redirectCodeSchema,
      }))
      .mutation(({ input }) => db.updateSettings(input)),
  }),
});

export type AppRouter = typeof appRouter;
