import { describe, expect, it, vi } from "vitest";

describe("admin access configuration", () => {
  it("documents the protected ADMIN_EMAIL contract", async () => {
    vi.stubEnv("ADMIN_EMAIL", "Admin@Example.com");
    const { ENV } = await import("./_core/env");
    expect(ENV.adminEmail).toBe("admin@example.com");
    vi.unstubAllEnvs();
  });
});
