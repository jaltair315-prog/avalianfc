import { desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  appSettings,
  boards,
  type AppSettings,
  type Board,
  type InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

const DEFAULT_SETTINGS = {
  id: 1,
  virginMode: "message" as const,
  salesWhatsapp: null,
  virginMessage: "Esta placa ainda não foi ativada. Entre em contato com a Avalia NFC.",
  defaultRedirectCode: "302" as const,
};

// Lazily create the client so project tooling remains usable without a local DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requireDb<T>(db: T | null): T {
  if (!db) throw new Error("Banco de dados indisponível. Verifique DATABASE_URL e as migrations.");
  return db;
}

export function normalizeGoogleReviewUrl(rawUrl: string): string {
  const input = rawUrl.trim();
  if (!input) return "";

  let parsed: URL;
  try {
    parsed = new URL(input);
  } catch {
    throw new Error("Informe uma URL válida para a avaliação do Google.");
  }

  if (parsed.protocol !== "https:") {
    throw new Error("Use uma URL HTTPS para a avaliação do Google.");
  }

  const host = parsed.hostname.toLowerCase();
  const allowedHosts = ["google.com", "g.page", "maps.app.goo.gl", "search.google.com"];
  const isGoogleHost = allowedHosts.some(
    allowed => host === allowed || host.endsWith(`.${allowed}`)
  );
  if (!isGoogleHost) {
    throw new Error("O destino precisa ser um link de avaliação do Google, g.page ou Google Maps.");
  }

  return parsed.toString();
}

export function normalizeWhatsapp(rawValue: string | null | undefined): string | null {
  const value = rawValue?.trim();
  if (!value) return null;
  if (/^\+?\d{10,15}$/.test(value.replace(/[\s()-]/g, ""))) {
    return `https://wa.me/${value.replace(/\D/g, "")}`;
  }
  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:" || !/(^|\.)wa\.me$|(^|\.)whatsapp\.com$/i.test(parsed.hostname)) {
      throw new Error();
    }
    return parsed.toString();
  } catch {
    throw new Error("Informe um número de WhatsApp ou uma URL https://wa.me válida.");
  }
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = requireDb(await getDb());

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (
    user.openId === ENV.ownerOpenId ||
    (ENV.adminEmail && typeof user.email === "string" && user.email.trim().toLowerCase() === ENV.adminEmail)
  ) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listBoards(): Promise<Board[]> {
  const db = requireDb(await getDb());
  return db.select().from(boards).orderBy(boards.sequence);
}

export async function getBoardBySlug(slug: string): Promise<Board | undefined> {
  const db = requireDb(await getDb());
  const result = await db.select().from(boards).where(eq(boards.slug, slug)).limit(1);
  return result[0];
}

export async function createBoard(defaultRedirectCode: "301" | "302" = "302"): Promise<Board> {
  const db = requireDb(await getDb());

  // Retry protects the unique sequence when two operators create a board at once.
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const current = await db
      .select({ maxSequence: sql<number>`coalesce(max(${boards.sequence}), 0)` })
      .from(boards);
    const sequence = Number(current[0]?.maxSequence ?? 0) + 1;
    const slug = String(sequence).padStart(2, "0");
    try {
      await db.insert(boards).values({
        sequence,
        slug,
        name: `Placa ${slug}`,
        status: "virgin",
        redirectCode: defaultRedirectCode,
      });
      const created = await getBoardBySlug(slug);
      if (created) return created;
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message.toLowerCase() : "";
      if (!message.includes("duplicate")) throw error;
    }
  }
  throw new Error("Não foi possível reservar a próxima sequência. Tente novamente.");
}

export async function updateBoard(input: {
  id: number;
  name?: string;
  googleReviewUrl?: string | null;
  redirectCode?: "301" | "302";
}): Promise<Board> {
  const db = requireDb(await getDb());
  const current = await db.select().from(boards).where(eq(boards.id, input.id)).limit(1);
  if (!current[0]) throw new Error("Placa não encontrada.");

  const updates: Record<string, unknown> = {};
  if (input.name !== undefined) {
    const name = input.name.trim();
    if (name.length < 2 || name.length > 120) throw new Error("O nome da placa deve ter entre 2 e 120 caracteres.");
    updates.name = name;
  }
  if (input.redirectCode !== undefined) updates.redirectCode = input.redirectCode;
  if (input.googleReviewUrl !== undefined) {
    const normalized = input.googleReviewUrl ? normalizeGoogleReviewUrl(input.googleReviewUrl) : null;
    updates.googleReviewUrl = normalized;
    updates.status = normalized ? "active" : "virgin";
    // A URL pública é dinâmica: ao mudar o destino, 302 evita que navegadores
    // preservem permanentemente o redirecionamento anterior.
    if (normalized && normalized !== current[0].googleReviewUrl) updates.redirectCode = "302";
  }

  if (Object.keys(updates).length === 0) return current[0];
  await db.update(boards).set(updates).where(eq(boards.id, input.id));
  const result = await db.select().from(boards).where(eq(boards.id, input.id)).limit(1);
  return result[0]!;
}

export async function deleteBoard(id: number): Promise<void> {
  const db = requireDb(await getDb());
  await db.delete(boards).where(eq(boards.id, id));
}

export async function getSettings(): Promise<AppSettings> {
  const db = requireDb(await getDb());
  const result = await db.select().from(appSettings).where(eq(appSettings.id, 1)).limit(1);
  if (result[0]) return result[0];
  try {
    await db.insert(appSettings).values(DEFAULT_SETTINGS);
  } catch {
    // A concurrent first request can create the fixed settings row first.
  }
  const created = await db.select().from(appSettings).where(eq(appSettings.id, 1)).limit(1);
  if (!created[0]) throw new Error("Não foi possível inicializar as configurações da Avalia NFC.");
  return created[0];
}

export async function updateSettings(input: {
  virginMode: "whatsapp" | "message";
  salesWhatsapp?: string | null;
  virginMessage: string;
  defaultRedirectCode: "301" | "302";
}): Promise<AppSettings> {
  const db = requireDb(await getDb());
  const virginMessage = input.virginMessage.trim();
  if (virginMessage.length < 8 || virginMessage.length > 1000) {
    throw new Error("A mensagem para placa virgem deve ter entre 8 e 1000 caracteres.");
  }
  const salesWhatsapp = normalizeWhatsapp(input.salesWhatsapp);
  if (input.virginMode === "whatsapp" && !salesWhatsapp) {
    throw new Error("Informe o WhatsApp de vendas antes de ativar esse modo.");
  }

  await getSettings();
  await db.update(appSettings).set({
    virginMode: input.virginMode,
    salesWhatsapp,
    virginMessage,
    defaultRedirectCode: input.defaultRedirectCode,
  }).where(eq(appSettings.id, 1));
  return getSettings();
}

export async function latestBoards(limit = 12): Promise<Board[]> {
  const db = requireDb(await getDb());
  return db.select().from(boards).orderBy(desc(boards.sequence)).limit(limit);
}
