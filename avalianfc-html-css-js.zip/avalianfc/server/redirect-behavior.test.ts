import { describe, expect, it } from "vitest";

describe("dynamic redirect behavior", () => {
  it("uses temporary redirects as the safe default for editable destinations", () => {
    expect("302").toBe("302");
  });

  it("documents that printed QR codes must point to /p/<slug>", () => {
    expect("https://example.test/p/01").toMatch(/\/p\/01$/);
  });
});
