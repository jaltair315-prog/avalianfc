import { describe, expect, it } from "vitest";
import { normalizeGoogleReviewUrl, normalizeWhatsapp } from "./db";

describe("validation rules for Avalia NFC destinations", () => {
  it("accepts supported Google review links over HTTPS", () => {
    expect(normalizeGoogleReviewUrl("https://g.page/r/Cd12Review/review")).toContain("g.page");
    expect(normalizeGoogleReviewUrl("https://maps.app.goo.gl/abc123")).toContain("maps.app.goo.gl");
    expect(normalizeGoogleReviewUrl("https://www.google.com/search?q=avaliacao")).toContain("google.com");
  });

  it("rejects unrelated and unsafe review destinations", () => {
    expect(() => normalizeGoogleReviewUrl("http://google.com/review")).toThrow(/HTTPS/);
    expect(() => normalizeGoogleReviewUrl("https://example.com/review")).toThrow(/Google/);
    expect(() => normalizeGoogleReviewUrl("javascript:alert(1)")).toThrow();
  });

  it("normalizes Brazilian WhatsApp numbers and validates URL hosts", () => {
    expect(normalizeWhatsapp("(11) 99999-9999")).toBe("https://wa.me/11999999999");
    expect(normalizeWhatsapp("https://wa.me/5511999999999")).toContain("wa.me");
    expect(normalizeWhatsapp("")).toBeNull();
    expect(() => normalizeWhatsapp("https://example.com/whatsapp")).toThrow(/WhatsApp/);
  });
});
