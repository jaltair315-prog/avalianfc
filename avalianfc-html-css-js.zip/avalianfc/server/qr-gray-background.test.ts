import { describe, expect, it } from "vitest";

describe("horizontal plaque QR background", () => {
  it("uses transparency so the reconstructed plaque gray remains visible", () => {
    const qrBackground = "#00000000";
    expect(qrBackground).toBe("#00000000");
    expect(qrBackground).not.toBe("#FFFFFFFF");
  });
});
