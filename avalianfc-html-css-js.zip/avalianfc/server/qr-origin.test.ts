import { describe, expect, it } from "vitest";
import type { Request } from "express";
import { publicBoardUrl } from "./qrcodes";

describe("QR public origin", () => {
  it("uses the panel origin supplied by the download request", () => {
    const request = { query: { baseUrl: "https://preview.example.test" }, get: () => undefined } as unknown as Request;
    expect(publicBoardUrl("01", request)).toBe("https://preview.example.test/p/01");
  });

  it("rejects an unsafe requested origin and falls back to the configured/default origin", () => {
    const request = { query: { baseUrl: "javascript:alert(1)" }, get: () => undefined } as unknown as Request;
    expect(publicBoardUrl("02", request)).toBe("https://avalianfc.com.br/p/02");
  });
});
