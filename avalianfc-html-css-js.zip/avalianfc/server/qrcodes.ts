import * as archiverModule from "archiver";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import type { Request, Response } from "express";
import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import type { Board } from "../drizzle/schema";
import * as db from "./db";
import { isMasterAuthenticated } from "./_core/masterAuth";

const DEFAULT_PUBLIC_BASE_URL = "https://avalianfc.com.br";

type ZipArchive = {
  on(event: "error", listener: (error: Error) => void): ZipArchive;
  pipe(destination: NodeJS.WritableStream): NodeJS.WritableStream;
  append(source: string | Buffer, data: { name: string }): void;
  finalize(): Promise<void>;
};

const createZipArchive = archiverModule as unknown as (
  format: "zip",
  options: { zlib: { level: number } }
) => ZipArchive;

export function publicBoardUrl(slug: string, req?: Request) {
  const configuredBase = process.env.PUBLIC_BASE_URL?.trim();
  const requestedBase = typeof req?.query.baseUrl === "string" ? req.query.baseUrl.trim() : undefined;
  const originHeader = req?.get("origin")?.trim();
  const referer = req?.get("referer")?.trim();
  let requestBase = originHeader;
  if (!requestBase && referer) {
    try { requestBase = new URL(referer).origin; } catch { requestBase = undefined; }
  }
  let requestedOrigin: string | undefined;
  if (requestedBase) {
    try {
      const parsed = new URL(requestedBase);
      if (parsed.protocol === "https:" || parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1") {
        requestedOrigin = parsed.origin;
      }
    } catch { requestedOrigin = undefined; }
  }
  const base = (requestedOrigin || configuredBase || requestBase || DEFAULT_PUBLIC_BASE_URL).replace(/\/$/, "");
  return `${base}/p/${encodeURIComponent(slug)}`;
}

async function requireAdmin(req: Request, res: Response) {
  if (isMasterAuthenticated(req)) return true;
  {
    res.status(401).json({ error: "Sessão expirada. Entre novamente no painel." });
    return false;
  }
}

async function qrBuffer(board: Board, req?: Request, light = "#FFFFFFFF") {
  return QRCode.toBuffer(publicBoardUrl(board.slug, req), {
    type: "png",
    errorCorrectionLevel: "M",
    margin: 3,
    width: 920,
    color: { dark: "#102A33", light },
  });
}

function parseRequestedSlugs(raw: unknown): string[] | null {
  if (typeof raw !== "string" || !raw.trim()) return null;
  const values = raw.split(",").map(value => value.trim()).filter(Boolean);
  return values.length ? values.slice(0, 500) : null;
}

async function selectedBoards(req: Request) {
  const all = await db.listBoards();
  // A exportação da gráfica com includeVirgin=1 sempre leva todas as placas,
  // inclusive as que ainda não têm destino de avaliação configurado.
  if (req.query.includeVirgin === "1") return all;
  const requested = parseRequestedSlugs(req.query.slugs);
  return requested ? all.filter(board => requested.includes(board.slug)) : all;
}

async function writeHorizontalThemePdf(doc: PDFKit.PDFDocument, boards: Board[], req: Request, theme: "blue" | "blue-black") {
  const assetName = theme === "blue" ? "cartao-horizontal-azul.jpg" : "cartao-horizontal-4k.png";
  const referencePath = [
    resolve(process.cwd(), `dist/public/${assetName}`),
    resolve(process.cwd(), `client/public/${assetName}`),
  ].find(existsSync);
  if (!referencePath) throw new Error(`Imagem base ${theme} não encontrada.`);
  const referenceCard = readFileSync(referencePath);
  const perPage = 6;
  const cardWidth = 250;
  const cardHeight = 213;
  const positions = [
    { x: 36, y: 36 }, { x: 306, y: 36 },
    { x: 36, y: 315 }, { x: 306, y: 315 },
    { x: 36, y: 594 }, { x: 306, y: 594 },
  ];
  for (let index = 0; index < boards.length; index += 1) {
    if (index > 0 && index % perPage === 0) doc.addPage();
    const board = boards[index];
    const position = positions[index % perPage];
    const { x, y } = position;
    const qr = await qrBuffer(board, req, "#00000000");
    doc.save();
    doc.image(referenceCard, x, y, { fit: [cardWidth, cardHeight] });
    // O QR dinâmico ocupa o espaço esquerdo da faixa inferior;
    // o conjunto NFC/celular permanece à direita, como no exemplo.
    const qrX = x + 31;
    const qrY = y + 125;
    doc.image(qr, qrX, qrY, { fit: [72, 72] });
    doc.fillColor("#707780").font("Helvetica").fontSize(5.5)
      .text(`/p/${board.slug}`, x + 27, y + 198, { width: 80, align: "center" });
    doc.roundedRect(x, y, cardWidth, cardHeight, 7).strokeColor("#D5DCE8").lineWidth(0.6).stroke();
    doc.restore();
  }
}

export function registerQrCodeRoutes(app: import("express").Express) {
  app.get("/api/qrcodes/:slug.png", async (req, res) => {
    if (!(await requireAdmin(req, res))) return;
    const board = await db.getBoardBySlug(req.params.slug);
    if (!board) {
      res.status(404).json({ error: "Placa não encontrada." });
      return;
    }
    const image = await qrBuffer(board, req);
    res
      .status(200)
      .set({
        "Content-Type": "image/png",
        "Content-Disposition": `attachment; filename="avalia-nfc-placa-${board.slug}.png"`,
        "Cache-Control": "private, no-store",
      })
      .send(image);
  });

  app.get("/api/qrcodes.zip", async (req, res) => {
    if (!(await requireAdmin(req, res))) return;
    const selected = await selectedBoards(req);
    if (!selected.length) {
      res.status(404).json({ error: "Não há placas para exportar." });
      return;
    }

    res.status(200).set({
      "Content-Type": "application/zip",
      "Content-Disposition": "attachment; filename=avalia-nfc-qrcodes.zip",
      "Cache-Control": "private, no-store",
    });
    const archive = createZipArchive("zip", { zlib: { level: 9 } });
    archive.on("error", (error: Error) => {
      console.error("[QR ZIP]", error);
      if (!res.headersSent) res.status(500).end();
      else res.end();
    });
    archive.pipe(res);
    archive.append(
      [
        "Avalia NFC — QR Codes para gráfica",
        `Gerado em: ${new Date().toLocaleString("pt-BR")}`,
        "Este PDF inclui todas as placas, inclusive as virgens ainda não ativadas.",
        "Cada QR Code aponta para a URL pública da placa correspondente.",
        "Em produção, defina PUBLIC_BASE_URL com o domínio final antes de imprimir. No Preview, o QR usa a origem atual do painel.",
      ].join("\n"),
      { name: "LEIA-ME.txt" }
    );
    for (const board of selected) {
      archive.append(await qrBuffer(board, req), { name: `placa-${board.slug}.png` });
    }
    await archive.finalize();
  });

  app.get("/api/qrcodes.pdf", async (req, res) => {
    if (!(await requireAdmin(req, res))) return;
    const selected = await selectedBoards(req);
    if (!selected.length) {
      res.status(404).json({ error: "Não há placas para exportar." });
      return;
    }

    const theme = req.query.theme === "blue" || req.query.theme === "blue-black" ? req.query.theme : null;
    res.status(200).set({
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename=${theme === "blue" ? "avalia-nfc-qrcodes-azul.pdf" : theme === "blue-black" ? "avalia-nfc-qrcodes-azul-preto.pdf" : "avalia-nfc-qrcodes-grafica.pdf"}`,
      "Cache-Control": "private, no-store",
    });
    const doc = new PDFDocument({ size: "A4", margin: 36, info: { Title: "Avalia NFC — QR Codes" } });
    doc.pipe(res);

    if (theme) {
      await writeHorizontalThemePdf(doc, selected, req, theme);
      doc.end();
      return;
    }

    const perPage = 6;
    for (let index = 0; index < selected.length; index += 1) {
      if (index > 0 && index % perPage === 0) doc.addPage();
      const board = selected[index];
      const slot = index % perPage;
      const column = slot % 2;
      const row = Math.floor(slot / 2);
      const x = 48 + column * 252;
      const y = 58 + row * 244;
      const image = await qrBuffer(board, req);
      doc.roundedRect(x, y, 210, 216, 8).strokeColor("#DCE6E4").lineWidth(1).stroke();
      doc.fillColor("#102A33").fontSize(16).font("Helvetica-Bold").text(board.name, x + 16, y + 16, { width: 178 });
      doc.image(image, x + 43, y + 48, { fit: [124, 124] });
      // Identificador técnico discreto para a gráfica, logo abaixo do QR.
      doc.fillColor("#8A999D").fontSize(6).font("Helvetica")
        .text(`/p/${board.slug}`, x + 16, y + 177, { width: 178, align: "center" });
      doc.fillColor("#A3AFB1").fontSize(6).font("Helvetica")
        .text("Avalia NFC", x + 16, y + 207, { width: 178, align: "center" });
    }
    doc.end();
  });
}
